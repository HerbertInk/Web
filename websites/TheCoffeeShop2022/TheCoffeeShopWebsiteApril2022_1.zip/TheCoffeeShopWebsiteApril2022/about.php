<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About our Coffee</title>

    <!--css file-->
    <link rel="stylesheet" href="inkhomestyle.css">
    
    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="navstyle.css">
        
    <!-- ===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


</head>
<body>

    <nav>
            <div class="nav-bar">
                <i class='bx bx-menu sidebarOpen' ></i>
                <span class="logo navLogo"><a href="#">The Ink Coffee shop</a></span>
                <span class="logo navLogo"><a href="#"><img src="images/logo.png" alt=""></a></span>

                <div class="menu">
                    <div class="logo-toggle">
                        <span class="logo"><a href="#">The Ink Coffee Shop</a></span>

                        <i class='bx bx-x siderbarClose'></i>
                    </div>

                    <ul class="nav-links">
                        <a href="inkhome.php#home">Home</a>
                        <a href="about.php">About</a>
                        <a href="coffee.php">Our Coffee</a>
                        <a href="product.php">Products</a>
                        <a href="inkhome.php#review">Review</a>
                        <a href="subscription.php">Subscribe</a>
                        <a href="blog.php">Blogs</a>
                        <a href="developer.php">Developer</a>
                        
                    </ul>
                </div>

                <div class="darkLight-searchBox">
                    <div class="dark-light">
                        <i class='bx bx-moon moon'></i>
                        <i class='bx bx-sun sun'></i>
                    </div>

                    <div class="searchBox">
                    <div class="searchToggle">
                        <i class='bx bx-x cancel'></i>
                        <i class='bx bx-search search'></i>
                    </div>

                        <div class="search-field">
                            <input type="text" placeholder="Search...">
                            <i class='bx bx-search'></i>
                        </div>
                    </div>
                </div>
            </div>
        </nav>

        <script src="navscript.js"></script>

<!--about-->

<section class="about" id="about">
    
    <h1 class="heading"> . <span> . </span> </h1>
    <h1 class="heading">About <span>Us</span> </h1>

    <div class="row">

        <div class="image">
            <!--img src="images/about-img.jpeg" alt=""-->
            <img src="InBlack.jpg" alt="">
        </div>

        <div class="content">
            <h3>what makes our coffee special?</h3>
            <p>The Ink coffee shop runs on love, laughter, and a whole lot of strong coffee.</p>
            <p>Our Coffee is Freshly roasted, lovingly brewed and this has made us keep up with the great taste
                having been One thing needed for a good day, a good breakfast, noon and night</p>
            <p>I was taken by the power that savouring a simple cup of coffee
                    can have to connect people and create community.</p>
             <p>Drink The Moment!!!</p>

            <a href="#blogs" class="btn">learn more</a>
        </div>

    </div>

</section>

<!--about-->
<!--footer-->

<section class="footer">

    <div class="share">
        <a href="https://facebook.com/Herbert.Ink20" class="fab fa-facebook-f"></a>
        <a href="https://twitter.com/Herbert_Ink" class="fab fa-twitter"></a>
        <a href="https://instagram.com/herbert.ink_21" class="fab fa-instagram"></a>
        <a href="https://linkedin.com/in/herbert-nduhura-ink20se" class="fab fa-linkedin"></a>
    </div>

    <div class="links">
        <a href="#home">Home</a>
        <a href="about.php">About Us</a>
        <a href="#coffee">Our Coffee</a>
        <a href="product.php">Products</a>
        <a href="#review">Review</a>
        <a href="subscription.php">Subscribe</a>
        <a href="blog.php">Blogs</a>
        <a href="developer.php">Developer</a>
        
    </div>

    <div class="credit">
        Created by <span>Ink</span> | 2022
    </div>

</section>

<!--footer-->

</body>
</html>