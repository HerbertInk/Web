<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer</title>

    <!--css file-->
    <link rel="stylesheet" href="inkhomestyle.css">
    <!--link rel="stylesheet" href="styleProfile.css"-->
            
    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="navstyle.css">
        
    <!-- ===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


</head>

<body>
    <nav>
        <div class="nav-bar">
            <i class='bx bx-menu sidebarOpen' ></i>
            <span class="logo navLogo"><a href="#">The Ink Coffee shop</a></span>
            <span class="logo navLogo"><a href="#"><img src="images/logo.png" alt=""></a></span>

            <div class="menu">
                <div class="logo-toggle">
                    <span class="logo"><a href="#">The Ink Coffee Shop</a></span>

                    <i class='bx bx-x siderbarClose'></i>
                </div>

                <ul class="nav-links">
                    <a href="inkhome.php#home">Home</a>
                    <a href="about.php">About</a>
                    <a href="coffee.php">Our Coffee</a>
                    <a href="product.php">Products</a>
                    <a href="inkhome.php#review">Review</a>
                    <a href="subscription.php">Subscribe</a>
                    <a href="blog.php">Blogs</a>
                    <a href="developer.php">Developer</a>        
                </ul>
            </div>

            <div class="darkLight-searchBox">
                <div class="dark-light">
                    <i class='bx bx-moon moon'></i>
                    <i class='bx bx-sun sun'></i>
                </div>
            </div>

            <div class="searchBox">

                <div class="searchToggle">
                    <i class='bx bx-x cancel'></i>
                    <i class='bx bx-search search'></i>
                </div>

                <div class="search-field">
                    <input type="text" placeholder="Search...">
                    <i class='bx bx-search'></i>
                </div>
            </div>
            
        </div>
    </nav>

        <script src="navscript.js"></script>
  
<!--Pic section-->

<!--About the Developer-->

    <section class="dev" id="dev">
    
        <h4 class="heading"> . <span> . </span></h4>
        <h4 class="heading"> The <span> Developer </span></h4>
        
        <div class="box-container">

            <div class="box">
                <img src="dp.jpg" alt="">
                <h3>Herbert Ink</h3>

                <div class="for-bold">
                    <p>Herbert Nduhura alias Ink is a student of MBARARA UNIVERSITY OF SCIENCE AND TECHNOLOGY doing
                        Bachelors of Science in Software Enginerring, Year 2.
                    </p><br>
                    <p>Am a lover of Coffee</p>

                    <h3>Ink</h3>
                </div>
                
                <a href="https://twitter.com/Herbert_Ink" class="btn">@Herbert_Ink</a>
            </div>
        </div>
    </section>
    <!-- footer section -->

    <section class="footer">

        <div class="share">
            <a href="https://facebook.com/Herbert.Ink20" class="fab fa-facebook-f"></a>
            <a href="https://twitter.com/Herbert_Ink" class="fab fa-twitter"></a>
            <a href="https://instagram.com/herbert.ink_21" class="fab fa-instagram"></a>
            <a href="https://linkedin.com/in/herbert-nduhura-ink20se" class="fab fa-linkedin"></a>
        </div>

        <div class="links">
            <a href="inkhome.html#home">Home</a>
            <a href="inkhome.html#about">About Us</a>
            <a href="inkhome.html#coffee">Our Coffee</a>
            <a href="inkhome.html#products">Products</a>
            <a href="inkhome.html#review">review</a>
            <a href="subscription.html">Subscribe</a>
            <a href="inkhome.html#blogs">Blogs</a>
            <a href="developer.html">Developer</a>
        </div>

        <div class="credit">
            Created by <span>Ink</span> | 2022
        </div>

    </section>

    <!--footer-->

</body>
</html>