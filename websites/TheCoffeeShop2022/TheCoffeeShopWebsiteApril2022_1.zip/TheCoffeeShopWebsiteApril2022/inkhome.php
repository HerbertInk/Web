<!DOCTYPE html>
<php lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>The Ink Coffee Shop - Home</title>

    <!--css file-->
    <link rel="stylesheet" href="inkhomestyle.css">
        
    <!-- ===== CSS ===== -->
    <link rel="stylesheet" href="navstyle.css">
        
    <!-- ===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

</head>
<body>
    
    <nav>
        <div class="nav-bar">
            <i class='bx bx-menu sidebarOpen' ></i>
            <span class="logo navLogo"><a href="#">The Ink Coffee shop</a></span>
            <span class="logo navLogo"><a href="#"><img src="images/logo.png" alt=""></a></span>

            <div class="menu">
                <div class="logo-toggle">
                    <span class="logo"><a href="#">The Ink Coffee Shop</a></span>

                    <i class='bx bx-x siderbarClose'></i>
                </div>

                <ul class="nav-links">
                    <a href="inkhome.php#home">Home</a>
                    <a href="about.php">About</a>
                    <a href="coffee.php">Our Coffee</a>
                    <a href="product.php">Products</a>
                    <a href="#review">Review</a>
                    <a href="subscription.php">Subscribe</a>
                    <a href="blog.php">Blogs</a>
                    <a href="developer.php">Developer</a>        
                </ul>
            </div>

            <div class="darkLight-searchBox">
                <div class="dark-light">
                    <i class='bx bx-moon moon'></i>
                    <i class='bx bx-sun sun'></i>
                </div>
            </div>

            <div class="searchBox">

                <div class="searchToggle">
                    <i class='bx bx-x cancel'></i>
                    <i class='bx bx-search search'></i>
                </div>

                <div class="search-field">
                    <input type="text" placeholder="Search...">
                    <i class='bx bx-search'></i>
                </div>
            </div>

        
        </div>
    </nav>

        <script src="navscript.js"></script>

<!--home-->

<section class="home" id="home">

    <div class="content">

        <h3>Start your day with coffee</h3>
        <p>Coffee on a warm summer day reminds you there’s a bright side to every day, 
            <p>Drink the moment!!!</p></p>
        <a href="#coffee" class="btn">Get coffee, Buy time</a>

    </div>

</section>

<!--home-->

<!--review-->

<section class="review" id="review">
    <h1 class="heading"> customer's <span>Review</span> </h1>
    <div class="box-container">

        <div class="box">
            <img src="images/quote-img.png" alt="" class="quote">

            <p>I like this coffee it's really smooth and has an after taste of chocolate.
                Service was brilliant and was ground perfectly for the Cafetiere.</p>

            <img src="" class="user" alt="">
            <h3>Kevin I</h3>

            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>

        </div>

        <div class="box">
            <img src="images/quote-img.png" alt="" class="quote">

            <p>It's the coffee shop that I visited during my stay and I kept going back.
                The staff was so welcoming and the prices for coffee are amazing.There is Wifi and lovely seating.
                It is a great coffee shops to meet new people in. The coolest thing was the Latte art
                that surprised me when I ordered.
                There was a Pirate in my Latte....so unique. </p>

            <img src="" class="user" alt="">
            <h3>Victorious I</h3>

            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>

        </div>

        <div class="box">
            <img src="images/quote-img.png" alt="" class="quote">

            <p>Fabulous aroma, very smooth everyday coffee.
                This one is definitely my favourite of them all.
                Enjoyed every moment.</p>

            <img src="" class="user" alt="">
            <h3>Kwizera E</h3>

            <div class="stars">
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star"></i>
                <i class="fas fa-star-half-alt"></i>
            </div>

        </div>
    </div>
</section>

<!--review-->

<!--footer-->

<section class="footer">

    <div class="share">
        <a href="https://facebook.com/Herbert.Ink20" class="fab fa-facebook-f"></a>
        <a href="https://twitter.com/Herbert_Ink" class="fab fa-twitter"></a>
        <a href="https://instagram.com/herbert.ink_21" class="fab fa-instagram"></a>
        <a href="https://linkedin.com/in/herbert-nduhura-ink20se" class="fab fa-linkedin"></a>
    </div>

    <div class="links">
        <a href="#home">Home</a>
        <a href="about.php">About Us</a>
        <a href="#coffee">Our Coffee</a>
        <a href="product.php">Products</a>
        <a href="#review">Review</a>
        <a href="subscription.php">Subscribe</a>
        <a href="blog.php">Blogs</a>
        <a href="developer.php">Developer</a>
        
    </div>

    <div class="credit">
        Created by <span>Ink</span> | 2022
    </div>

</section>

<!--footer-->

</body>
</php>