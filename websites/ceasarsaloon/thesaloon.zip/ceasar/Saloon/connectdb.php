<?php
        $host="localhost";
		$uname="root";
		$pas="";
		$db_name="ssaloon";		
		$conn = @mysqli_connect("$host","$uname","$pas","$db_name") or die ("unable to connect");
		?>