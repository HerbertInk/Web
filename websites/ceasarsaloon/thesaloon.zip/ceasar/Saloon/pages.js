function appoint() {
    window.location.href = "appointment.php";
}